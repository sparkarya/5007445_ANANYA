package com.example.ex1_ex2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ex1Ex2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
